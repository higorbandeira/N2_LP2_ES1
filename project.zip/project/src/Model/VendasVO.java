package Model;

public class VendasVO {

	private int VendaID;
	private double Valor;

	public int getVendaID() {
		return VendaID;
	}
	public void setVendaID(double VendaID) {
		Valor = VendaID;
	}

	public double getValor() {
		return Valor;
	}
	public void setValor(double value) {
		Valor = value;
	}
}