package Model;

public class ItemDeVendaVO {

	private int VendaID;
	private int ProdutoID;
	private int Quantidade;

	public int getVendaID() {
		return VendaID;
	}
	public void setVendaID(int valor) {
		VendaID = valor;
	}

	public int getProdutoID() {
		return ProdutoID;
	}
	public void setProdutoID(int valor) {
		ProdutoID = valor;
	}

	public int getQuantidade() {
		return Quantidade;
	}
	public void setQuantidade(int valor) {
		Quantidade = valor;
	}

}
