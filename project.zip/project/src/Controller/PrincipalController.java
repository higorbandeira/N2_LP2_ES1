package Controller;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.MenuItem;

public class PrincipalController implements Initializable {
	@FXML
    private MenuItem btnCadProduto;

    @FXML
    private Button btnVender;

    @FXML
    private MenuItem btnCadFuncionario;

    @FXML
    private MenuItem btnCadCliente;

    @FXML
    private Button btnHome;

    public void initialize(URL url, ResourceBundle rb){

    }
}
