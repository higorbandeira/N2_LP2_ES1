package Controller;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;

public class CadastrarClienteController implements Initializable {

	 @FXML
	    private Button btnCadastrar;

	 @FXML
	    private Button btnCancelar;

    public void initialize(URL url, ResourceBundle rb){

    }
}
